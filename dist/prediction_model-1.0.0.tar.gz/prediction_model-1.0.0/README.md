

## Virtual Environment
Intall virtualenv

'''python
python3 -m pip install virtualenv
'''

Check the version
'''python
virtualenv --version
'''

Create virtual environment
'''python
py -m venv ml_package
     OR
virtualenv my_package
'''

Activate virtual environment

For windows
'''python
ml_package\Scripts\activate.bat
'''

For Linux/MacOs
'''python
source my_package/bin/activate